import { Router, type IRouter, type Request } from "express";
import { db } from "@workspace/db";
import {
  usersTable, dataPlansTable, transactionsTable, walletsTable, notificationsTable,
  examTypesTable, settingsTable,
} from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { authenticate, type AuthRequest } from "../middlewares/auth";
import { refreshSettings } from "../lib/settingsCache";
import {
  GetDataPlansQueryParams,
  PurchaseDataBody,
  PurchaseAirtimeBody,
  VerifyMeterBody,
  PurchaseElectricityBody,
  GetCablePlansQueryParams,
  VerifySmartcardBody,
  SubscribeCableBody,
  PurchaseExamTokenBody,
} from "@workspace/api-zod";
import {
  isActiveProviderConfigured,
  isElectricityProviderConfigured,
  activePurchaseData,
  activePurchaseAirtime,
  activeVerifyMeter,
  activePurchaseElectricity,
  activePurchaseCable,
  activeVerifySmartcard,
  activePurchaseExam,
  activeGetElectricityBalance,
} from "../lib/providers/activeProvider";
import { ProviderTimeoutError } from "../lib/providers/errors";

type PurchaseType = "data" | "airtime" | "electricity" | "cable" | "exam";

// ── PENDING-REVIEW HELPER ───────────────────────────────────────────────────
// Used when a provider call times out client-side (AbortController fired)
// rather than returning a definitive failure. In that case we do NOT know
// whether the provider actually completed the purchase — refunding
// immediately can cause a double loss if it did. Instead we leave the wallet
// debited, record the transaction as "pending", and flag it for an admin to
// manually verify against the provider's own portal and resolve via
// POST /admin/transactions/:id/resolve.
async function recordPendingPurchase(opts: {
  userId: string; type: PurchaseType; amount: number; reference: string;
  description: string; metadata: Record<string, any>;
}) {
  const [tx] = await db.insert(transactionsTable).values({
    userId: opts.userId, type: opts.type as any, status: "pending", amount: opts.amount.toString(),
    description: opts.description, reference: opts.reference,
    metadata: { ...opts.metadata, awaitingReview: true },
  }).returning();
  await db.insert(notificationsTable).values({
    userId: opts.userId, title: "Purchase Processing",
    message: `Your ₦${opts.amount} ${opts.type} purchase is taking longer than usual to confirm. We're checking with the provider and will notify you shortly — please don't retry yet.`,
    type: opts.type as any,
  });
  return tx;
}

// ── LOW PROVIDER-BALANCE GUARD ──────────────────────────────────────────────
// Electricity providers (EasyAccess, KYB, BigISub) hold a prepaid float that
// funds customer purchases. When that float runs low, the provider rejects
// the purchase AFTER we'd already debit the customer — forcing an immediate
// refund and a broken experience (and, if the provider's rejection message
// is misread, a risk of the purchase actually going through while we still
// refund). Check the float before touching the customer's wallet so we can
// fail fast with a clear message instead.
const LOW_BALANCE_ALERT_COOLDOWN_MS = 15 * 60 * 1000;
async function alertAdminsOfLowProviderBalance(provider: string, balance: number, attemptedAmount: number): Promise<void> {
  try {
    const key = "elec_low_balance_alert_at";
    const [existing] = await db.select({ value: settingsTable.value }).from(settingsTable).where(eq(settingsTable.key, key));
    const lastAlert = existing?.value ? new Date(existing.value).getTime() : 0;
    if (Date.now() - lastAlert < LOW_BALANCE_ALERT_COOLDOWN_MS) return;

    const admins = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.role, "admin"));
    if (admins.length > 0) {
      await db.insert(notificationsTable).values(
        admins.map((admin) => ({
          userId: admin.id, title: "Electricity Provider Balance Low",
          message: `${provider} balance is only ₦${balance.toLocaleString()} — too low to cover a ₦${attemptedAmount.toLocaleString()} purchase. Electricity purchases are being blocked until you fund the ${provider} account. Go to Admin → Settings to check.`,
          type: "electricity" as any,
        }))
      );
    }
    await db.insert(settingsTable).values({ key, value: new Date().toISOString() })
      .onConflictDoUpdate({ target: settingsTable.key, set: { value: new Date().toISOString(), updatedAt: new Date() } });
  } catch (err) {
    // Never let alerting failure block/break the purchase-guard response.
  }
}

const KYB_ELEC_DISCO_ID: Record<string, string> = {
  "ikeja-electric":        "28",
  "abuja-electric":        "1",
  "kaduna-electric":       "74",
  "portharcourt-electric": "15",
  "ibadan-electric":       "14",
  "jos-electric":          "53",
  "kano-electric":         "63",
};

// ── RESELLER COMMISSION HELPER ────────────────────────────────────────────────
async function creditResellerCommission(
  userId: string,
  purchaseAmount: number,
  purchaseDesc: string,
  log?: any
): Promise<void> {
  try {
    const [buyer] = await db.select({ referredBy: usersTable.referredBy })
      .from(usersTable).where(eq(usersTable.id, userId));
    if (!buyer?.referredBy) return;

    const [referrer] = await db.select({ id: usersTable.id, role: usersTable.role })
      .from(usersTable).where(eq(usersTable.id, buyer.referredBy));
    if (!referrer || referrer.role !== "reseller") return;

    const [rateSetting] = await db.select({ value: settingsTable.value })
      .from(settingsTable).where(eq(settingsTable.key, "resellerCommissionRate"));
    const rate = parseFloat(rateSetting?.value ?? "3");
    const commission = Math.floor(purchaseAmount * rate / 100);
    if (commission < 1) return;

    await db.update(walletsTable)
      .set({ balance: sql`balance + ${commission}`, updatedAt: new Date() })
      .where(eq(walletsTable.userId, referrer.id));

    await db.insert(transactionsTable).values({
      userId: referrer.id,
      type: "commission" as any,
      status: "success",
      amount: commission.toString(),
      description: `Commission: ${purchaseDesc}`,
      reference: `COMM-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
      metadata: { fromUserId: userId, purchaseAmount, rate },
    });

    await db.insert(notificationsTable).values({
      userId: referrer.id,
      title: "💰 Commission Earned!",
      message: `You earned ₦${commission.toLocaleString()} commission from a referral's ${purchaseDesc}.`,
      type: "general",
    });
  } catch (err: any) {
    log?.error({ err }, "Commission credit error");
  }
}

const router: IRouter = Router();

// ── PUBLIC SETTINGS ───────────────────────────────────────────────────────────
router.get("/settings/public", async (_req, res): Promise<void> => {
  const settings = await db.select().from(settingsTable);
  const obj: Record<string, string> = {};
  for (const s of settings) obj[s.key] = s.value;
  res.json({
    announcement: obj.announcement ?? "",
    announcementActive: obj.announcementActive === "true",
    bankTransferActive: obj.bankTransferActive === "true",
    bankAccountNumber: obj.bankAccountNumber ?? "",
    bankAccountName: obj.bankAccountName ?? "",
    bankName: obj.bankName ?? "",
    resellerPromoActive: obj.resellerPromoActive === "true",
    resellerPromoEndDate: obj.resellerPromoEndDate ?? "",
    resellerPromoTitle: obj.resellerPromoTitle ?? "Become a Reseller — Limited Offer!",
    resellerPromoText: obj.resellerPromoText ?? "Activate your reseller account for just ₦500 and earn commission on every referral purchase. Offer ends soon!",
  });
});

// ── DATA ──────────────────────────────────────────────────────────────────────
router.get("/data/plans", async (req: Request, res): Promise<void> => {
  const params = GetDataPlansQueryParams.safeParse(req.query);
  const plans = await db.select().from(dataPlansTable).where(eq(dataPlansTable.isActive, true));
  const filtered = params.success && params.data.network
    ? plans.filter((p) => p.network === params.data.network)
    : plans;
  res.json(filtered.map((p) => ({
    id: p.id, network: p.network, name: p.name, size: p.size,
    validity: p.validity, price: parseFloat(p.price),
    resellerPrice: p.resellerPrice != null ? parseFloat(p.resellerPrice) : null,
    costPrice: parseFloat(p.costPrice), providerCode: p.providerCode, isActive: p.isActive,
  })));
});

router.post("/data/purchase", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const parsed = PurchaseDataBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { planId, phone } = parsed.data;

  const [plan] = await db.select().from(dataPlansTable).where(eq(dataPlansTable.id, planId));
  if (!plan || !plan.isActive) { res.status(404).json({ error: "Data plan not found or unavailable" }); return; }
  if (!plan.providerCode) { res.status(503).json({ error: "This data plan is not yet configured. Please contact support." }); return; }
  if (!isActiveProviderConfigured()) { res.status(503).json({ error: "Service temporarily unavailable. Please try again later." }); return; }

  const [user] = await db.select({ role: usersTable.role }).from(usersTable).where(eq(usersTable.id, req.userId!));
  const isReseller = user?.role === "reseller";
  const price = isReseller && plan.resellerPrice != null
    ? parseFloat(plan.resellerPrice)
    : parseFloat(plan.price);

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (parseFloat(wallet.balance) < price) {
    res.status(400).json({ error: "Insufficient wallet balance. Please fund your wallet to continue." }); return;
  }

  await db.update(walletsTable).set({ balance: sql`balance - ${price}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
  const reference = `DATA-${Date.now()}`;
  let delivered = false;
  let providerError = "";
  let rawResponse: any = null;
  let isTimeout = false;

  try {
    const r = await activePurchaseData({ plan: plan.providerCode, mobile_number: phone, network: plan.network });
    rawResponse = r;
    req.log?.info({ r }, "KYB Data purchase response");
    const success = (r as any).success === true;
    const st = String((r as any).status ?? "").toLowerCase();
    const msg = String(r.message ?? "").toLowerCase();
    delivered = success || st === "success" || st === "200" || st === "00"
      || msg.includes("success") || msg.includes("successful") || msg.includes("delivered");
    if (!delivered) {
      providerError = (r as any).data?.error_message?.api_response
        || (r as any).error_message?.api_response
        || r.message || "";
    }
  } catch (err: any) {
    req.log?.error({ err }, "Data purchase error");
    providerError = err?.message ?? "";
    isTimeout = err instanceof ProviderTimeoutError;
  }

  if (!delivered && isTimeout) {
    const tx = await recordPendingPurchase({
      userId: req.userId!, type: "data", amount: price, reference,
      description: `${plan.network} ${plan.name} data for ${phone} — awaiting confirmation`,
      metadata: { network: plan.network, size: plan.size, validity: plan.validity, phone, providerError },
    });
    res.status(202).json({ id: tx.id, status: "pending", message: "Your data purchase is being confirmed. We'll notify you shortly — please don't retry yet." });
    return;
  }

  if (!delivered) {
    await db.update(walletsTable).set({ balance: sql`balance + ${price}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
    await db.insert(transactionsTable).values({
      userId: req.userId!, type: "data", status: "failed", amount: price.toString(),
      description: `${plan.network} ${plan.name} data for ${phone} — delivery failed`, reference,
      metadata: { network: plan.network, size: plan.size, validity: plan.validity, phone, providerError, rawResponse },
    });
    await db.insert(notificationsTable).values({
      userId: req.userId!, title: "Data Purchase Failed",
      message: `Your ₦${price} data purchase failed. Your wallet has been refunded.`, type: "data",
    });
    const userMsg = providerError
      ? `Data delivery failed: ${providerError}. Your wallet has been refunded.`
      : "Data delivery failed. Your wallet has been refunded. Please try again or contact support.";
    res.status(422).json({ error: userMsg }); return;
  }

  const [tx] = await db.insert(transactionsTable).values({
    userId: req.userId!, type: "data", status: "success", amount: price.toString(),
    description: `${plan.network} ${plan.name} data for ${phone}`, reference,
    metadata: { network: plan.network, size: plan.size, validity: plan.validity, phone },
  }).returning();
  await db.insert(notificationsTable).values({
    userId: req.userId!, title: "Data Purchase Successful",
    message: `${plan.network} ${plan.size} data has been sent to ${phone}.`, type: "data",
  });
  void creditResellerCommission(req.userId!, price, `${plan.network} ${plan.name} data`, req.log);
  res.json({ id: tx.id, type: tx.type, status: tx.status, amount: parseFloat(tx.amount), description: tx.description, reference: tx.reference, metadata: tx.metadata, userId: tx.userId, createdAt: tx.createdAt });
});

// ── AIRTIME ───────────────────────────────────────────────────────────────────
router.post("/airtime/purchase", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const parsed = PurchaseAirtimeBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { network, phone, amount } = parsed.data;

  if (!isActiveProviderConfigured()) { res.status(503).json({ error: "Service temporarily unavailable. Please try again later." }); return; }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (parseFloat(wallet.balance) < amount) {
    res.status(400).json({ error: "Insufficient wallet balance. Please fund your wallet to continue." }); return;
  }

  await db.update(walletsTable).set({ balance: sql`balance - ${amount}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
  const reference = `AIRTIME-${Date.now()}`;
  let delivered = false;
  let providerError = "";
  let rawResponse: any = null;
  let isTimeout = false;

  try {
    const r = await activePurchaseAirtime({ network, amount, mobile_number: phone });
    rawResponse = r;
    req.log?.info({ r }, "KYB Data airtime response");
    const success = (r as any).success === true;
    const st = String((r as any).status ?? "").toLowerCase();
    const msg = String(r.message ?? "").toLowerCase();
    delivered = success || st === "success" || st === "200" || st === "00"
      || msg.includes("success") || msg.includes("successful") || msg.includes("delivered");
    if (!delivered) {
      providerError = (r as any).data?.error_message?.api_response
        || (r as any).error_message?.api_response
        || r.message || "";
    }
  } catch (err: any) {
    req.log?.error({ err }, "Airtime purchase error");
    providerError = err?.message ?? "";
    isTimeout = err instanceof ProviderTimeoutError;
  }

  if (!delivered && isTimeout) {
    const tx = await recordPendingPurchase({
      userId: req.userId!, type: "airtime", amount, reference,
      description: `${network} ₦${amount} airtime for ${phone} — awaiting confirmation`,
      metadata: { network, phone, amount, providerError },
    });
    res.status(202).json({ id: tx.id, status: "pending", message: "Your airtime purchase is being confirmed. We'll notify you shortly — please don't retry yet." });
    return;
  }

  if (!delivered) {
    await db.update(walletsTable).set({ balance: sql`balance + ${amount}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
    await db.insert(transactionsTable).values({
      userId: req.userId!, type: "airtime", status: "failed", amount: amount.toString(),
      description: `${network} ₦${amount} airtime for ${phone} — delivery failed`, reference,
      metadata: { network, phone, amount, providerError, rawResponse },
    });
    await db.insert(notificationsTable).values({
      userId: req.userId!, title: "Airtime Purchase Failed",
      message: `₦${amount} ${network} airtime failed. Your wallet has been refunded.`, type: "airtime",
    });
    const userMsg = providerError
      ? `Airtime delivery failed: ${providerError}. Your wallet has been refunded.`
      : "Airtime delivery failed. Your wallet has been refunded. Please try again or contact support.";
    res.status(422).json({ error: userMsg }); return;
  }

  const [tx] = await db.insert(transactionsTable).values({
    userId: req.userId!, type: "airtime", status: "success", amount: amount.toString(),
    description: `${network} ₦${amount} airtime for ${phone}`, reference,
    metadata: { network, phone, amount },
  }).returning();
  await db.insert(notificationsTable).values({
    userId: req.userId!, title: "Airtime Purchase Successful",
    message: `₦${amount} ${network} airtime has been sent to ${phone}.`, type: "airtime",
  });
  void creditResellerCommission(req.userId!, amount, `${network} airtime`, req.log);
  res.json({ id: tx.id, type: tx.type, status: tx.status, amount: parseFloat(tx.amount), description: tx.description, reference: tx.reference, metadata: tx.metadata, userId: tx.userId, createdAt: tx.createdAt });
});

// ── ELECTRICITY ───────────────────────────────────────────────────────────────
const ELECTRICITY_PROVIDERS = [
  { id: "ikeja-electric",        code: "ikeja-electric",        name: "Ikeja Electric (IKEDC)"        },
  { id: "abuja-electric",        code: "abuja-electric",        name: "Abuja Electric (AEDC)"         },
  { id: "kaduna-electric",       code: "kaduna-electric",       name: "Kaduna Electric (KAEDCO)"      },
  { id: "portharcourt-electric", code: "portharcourt-electric", name: "Port Harcourt Electric (PHED)" },
  { id: "ibadan-electric",       code: "ibadan-electric",       name: "Ibadan Electric (IBEDC)"       },
  { id: "jos-electric",          code: "jos-electric",          name: "Jos Electric (JED)"            },
  { id: "kano-electric",         code: "kano-electric",         name: "Kano Electric (KEDCO)"         },
];

router.get("/electricity/providers", authenticate, async (_req, res): Promise<void> => {
  res.json(ELECTRICITY_PROVIDERS);
});

router.post("/electricity/verify-meter", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const parsed = VerifyMeterBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { meterNumber, providerCode, meterType } = parsed.data;
  // Force a fresh read of routing settings — this path has previously misrouted
  // on stale per-instance state, so don't rely on the TTL window here.
  await refreshSettings();
  if (!isElectricityProviderConfigured()) { res.status(503).json({ error: "Service temporarily unavailable. Please try again later." }); return; }
  try {
    const discoId = KYB_ELEC_DISCO_ID[providerCode.toLowerCase()] ?? "1";
    const r: any = await activeVerifyMeter({ meter_number: meterNumber, discoid: discoId, meter_type: meterType ?? "prepaid", providerCode });
    const customerName = r?.data?.customer_name || r?.customer_name;
    if (!customerName) {
      req.log?.warn({ providerCode, meterNumber, rawResponse: r }, "Meter verify: no customer_name in provider response");
      const providerMsg = r?.message || r?.data?.message || "Could not verify this meter number. Please check it and try again.";
      res.status(422).json({ error: providerMsg });
      return;
    }
    res.json({ meterNumber, name: customerName, address: r?.data?.address || r?.address || "" });
  } catch (err: any) {
    req.log?.error({ err }, "Meter verify error");
    res.status(422).json({ error: err?.message || "Could not verify this meter number. Please check it and try again." });
  }
});

router.post("/electricity/purchase", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const parsed = PurchaseElectricityBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { meterNumber, providerCode, meterType, amount, phone } = parsed.data;

  if (amount < 500) { res.status(400).json({ error: "Minimum electricity purchase is ₦500" }); return; }
  // Force a fresh read of routing settings — this path has previously misrouted
  // on stale per-instance state, so don't rely on the TTL window here.
  await refreshSettings();
  if (!isElectricityProviderConfigured()) { res.status(503).json({ error: "Service temporarily unavailable. Please try again later." }); return; }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (parseFloat(wallet.balance) < amount) {
    res.status(400).json({ error: "Insufficient wallet balance. Please fund your wallet to continue." }); return;
  }

  try {
    const providerBalance = await activeGetElectricityBalance(providerCode);
    if (typeof providerBalance.balance === "number" && providerBalance.balance < amount) {
      req.log?.warn({ providerBalance, amount }, "Electricity purchase blocked: provider float too low");
      await alertAdminsOfLowProviderBalance(providerBalance.provider, providerBalance.balance, amount);
      res.status(503).json({ error: "Electricity purchases are temporarily unavailable. We're on it — please try again shortly." });
      return;
    }
  } catch (err) {
    // Balance pre-check itself failing shouldn't block a purchase attempt —
    // fall through and let the actual purchase call surface any real error.
    req.log?.warn({ err }, "Electricity provider balance pre-check failed; proceeding without it");
  }

  await db.update(walletsTable).set({ balance: sql`balance - ${amount}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
  const reference = `ELEC-${Date.now()}`;
  let elecToken = "";
  let delivered = false;
  let providerError = "";
  let rawResponse: any = null;
  let isTimeout = false;

  try {
    const discoId = KYB_ELEC_DISCO_ID[providerCode.toLowerCase()] ?? "1";
    const r = await activePurchaseElectricity({ discoid: discoId, MeterType: meterType ?? "prepaid", meter_number: meterNumber, amount, providerCode });
    rawResponse = r;
    req.log?.info({ r, providerCode }, "Electricity provider response");
    const success = (r as any).success === true;
    const st = String((r as any).status ?? "").toLowerCase();
    const msg = String(r.message ?? "").toLowerCase();
    delivered = success || st === "success" || st === "200" || st === "00"
      || msg.includes("success") || msg.includes("successful") || msg.includes("delivered");
    elecToken = r.token ?? (r as any).data?.token ?? "";
    if (!delivered) {
      providerError = (r as any).data?.error_message?.api_response
        || (r as any).error_message?.api_response
        || r.message || "";
    }
  } catch (err: any) {
    req.log?.error({ err }, "Electricity purchase error");
    providerError = err?.message ?? "";
    isTimeout = err instanceof ProviderTimeoutError;
  }

  if (!delivered && isTimeout) {
    const tx = await recordPendingPurchase({
      userId: req.userId!, type: "electricity", amount, reference,
      description: `Electricity for meter ${meterNumber} — awaiting confirmation`,
      metadata: { meterNumber, providerCode, meterType, phone, providerError },
    });
    res.status(202).json({ id: tx.id, status: "pending", message: "Your electricity purchase is being confirmed. We'll notify you shortly — please don't retry yet." });
    return;
  }

  if (!delivered) {
    await db.update(walletsTable).set({ balance: sql`balance + ${amount}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
    await db.insert(transactionsTable).values({
      userId: req.userId!, type: "electricity", status: "failed", amount: amount.toString(),
      description: `Electricity for meter ${meterNumber} — delivery failed`, reference,
      metadata: { meterNumber, providerCode, meterType, phone, providerError, rawResponse },
    });
    await db.insert(notificationsTable).values({
      userId: req.userId!, title: "Electricity Purchase Failed",
      message: `Your ₦${amount} electricity purchase failed. Your wallet has been refunded.`, type: "electricity",
    });
    const userMsg = providerError
      ? `Electricity delivery failed: ${providerError}. Your wallet has been refunded.`
      : "Electricity token delivery failed. Your wallet has been refunded.";
    res.status(422).json({ error: userMsg }); return;
  }

  const [tx] = await db.insert(transactionsTable).values({
    userId: req.userId!, type: "electricity", status: "success", amount: amount.toString(),
    description: `Electricity token for meter ${meterNumber}`, reference,
    metadata: { meterNumber, providerCode, meterType, token: elecToken, phone },
  }).returning();
  await db.insert(notificationsTable).values({
    userId: req.userId!, title: "Electricity Token Purchased",
    message: `Token: ${elecToken} for meter ${meterNumber}`, type: "electricity",
  });
  void creditResellerCommission(req.userId!, amount, "electricity token", req.log);
  res.json({ id: tx.id, status: "success", token: elecToken, amount, meterNumber, createdAt: tx.createdAt });
});

// ── CABLE TV ──────────────────────────────────────────────────────────────────
const CABLE_PROVIDERS = [
  { id: "dstv",      name: "DStv"      },
  { id: "gotv",      name: "GOtv"      },
  { id: "startimes", name: "StarTimes" },
];

const CABLE_PLANS = [
  { id: "dstv-54",  provider: "dstv",      name: "DStv Padi",         price: 4200,  validity: "Monthly", kybPlanId: 54  },
  { id: "dstv-25",  provider: "dstv",      name: "DStv Yanga",        price: 5800,  validity: "Monthly", kybPlanId: 25  },
  { id: "dstv-68",  provider: "dstv",      name: "DStv Confam",       price: 10500, validity: "Monthly", kybPlanId: 68  },
  { id: "dstv-67",  provider: "dstv",      name: "DStv Asia",         price: 13800, validity: "Monthly", kybPlanId: 67  },
  { id: "dstv-45",  provider: "dstv",      name: "DStv Compact",      price: 17500, validity: "Monthly", kybPlanId: 45  },
  { id: "dstv-52",  provider: "dstv",      name: "DStv Compact Plus", price: 27500, validity: "Monthly", kybPlanId: 52  },
  { id: "dstv-43",  provider: "dstv",      name: "DStv Premium",      price: 40500, validity: "Monthly", kybPlanId: 43  },
  { id: "gotv-58",  provider: "gotv",      name: "GOtv Smallie",      price: 2000,  validity: "Monthly", kybPlanId: 58  },
  { id: "gotv-22",  provider: "gotv",      name: "GOtv Jinja",        price: 3800,  validity: "Monthly", kybPlanId: 22  },
  { id: "gotv-76",  provider: "gotv",      name: "GOtv Jolli",        price: 5400,  validity: "Monthly", kybPlanId: 76  },
  { id: "gotv-23",  provider: "gotv",      name: "GOtv Max",          price: 8200,  validity: "Monthly", kybPlanId: 23  },
  { id: "gotv-60",  provider: "gotv",      name: "GOtv Supa",         price: 10800, validity: "Monthly", kybPlanId: 60  },
  { id: "st-57",    provider: "startimes", name: "StarTimes Nova",    price: 2300,  validity: "Monthly", kybPlanId: 57  },
  { id: "st-12",    provider: "startimes", name: "StarTimes Smart",   price: 4200,  validity: "Monthly", kybPlanId: 12  },
  { id: "st-75",    provider: "startimes", name: "StarTimes Basic",   price: 4200,  validity: "Monthly", kybPlanId: 75  },
  { id: "st-21",    provider: "startimes", name: "StarTimes Classic", price: 6200,  validity: "Monthly", kybPlanId: 21  },
  { id: "st-8",     provider: "startimes", name: "StarTimes Super",   price: 9800,  validity: "Monthly", kybPlanId: 8   },
];

router.get("/cable/providers", authenticate, async (_req, res): Promise<void> => {
  res.json(CABLE_PROVIDERS);
});

router.get("/cable/plans", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const params = GetCablePlansQueryParams.safeParse(req.query);
  const provider = (params.success ? params.data.provider ?? "" : "").toLowerCase();
  const filtered = provider ? CABLE_PLANS.filter((p) => p.provider === provider) : CABLE_PLANS;
  res.json(filtered.map(({ kybPlanId: _k, ...p }) => p));
});

router.post("/cable/verify-smartcard", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const parsed = VerifySmartcardBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { smartcardNumber, provider } = parsed.data as { smartcardNumber: string; provider?: string };
  if (!isActiveProviderConfigured() || !provider) { res.status(503).json({ error: "Service temporarily unavailable. Please try again later." }); return; }
  try {
    const r: any = await activeVerifySmartcard({ smart_card_number: smartcardNumber, cable_name: provider });
    const customerName = r?.data?.customer_name || r?.customer_name;
    if (!customerName) {
      const providerMsg = r?.message || r?.data?.message || "Could not verify this smartcard number. Please check it and try again.";
      res.status(422).json({ error: providerMsg });
      return;
    }
    res.json({ smartcardNumber, name: customerName, currentPlan: r?.data?.current_plan || r?.current_plan || "", dueDate: "" });
  } catch (err: any) {
    req.log?.error({ err }, "Smartcard verify error");
    res.status(422).json({ error: err?.message || "Could not verify this smartcard number. Please check it and try again." });
  }
});

router.post("/cable/subscribe", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const parsed = SubscribeCableBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { planId, smartcardNumber, provider } = parsed.data;

  const plan = CABLE_PLANS.find((p) => p.id === planId);
  if (!plan) { res.status(404).json({ error: "Plan not found" }); return; }
  if (!isActiveProviderConfigured()) { res.status(503).json({ error: "Service temporarily unavailable. Please try again later." }); return; }

  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (parseFloat(wallet.balance) < plan.price) {
    res.status(400).json({ error: "Insufficient wallet balance. Please fund your wallet to continue." }); return;
  }

  await db.update(walletsTable).set({ balance: sql`balance - ${plan.price}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
  const reference = `CABLE-${Date.now()}`;
  let delivered = false;
  let providerError = "";
  let rawResponse: any = null;
  let isTimeout = false;

  try {
    const r = await activePurchaseCable({ plan_id: plan.kybPlanId, smart_card_number: smartcardNumber });
    rawResponse = r;
    req.log?.info({ r }, "KYB Data cable response");
    const success = (r as any).success === true;
    const st = String((r as any).status ?? "").toLowerCase();
    const msg = String(r.message ?? "").toLowerCase();
    delivered = success || st === "success" || st === "200" || st === "00"
      || msg.includes("success") || msg.includes("successful") || msg.includes("delivered");
    if (!delivered) {
      providerError = (r as any).data?.error_message?.api_response
        || (r as any).error_message?.api_response
        || r.message || "";
    }
  } catch (err: any) {
    req.log?.error({ err }, "Cable subscribe error");
    providerError = err?.message ?? "";
    isTimeout = err instanceof ProviderTimeoutError;
  }

  if (!delivered && isTimeout) {
    const tx = await recordPendingPurchase({
      userId: req.userId!, type: "cable", amount: plan.price, reference,
      description: `${plan.name} for ${smartcardNumber} — awaiting confirmation`,
      metadata: { provider, planName: plan.name, smartcardNumber, providerError },
    });
    res.status(202).json({ id: tx.id, status: "pending", message: "Your cable subscription is being confirmed. We'll notify you shortly — please don't retry yet." });
    return;
  }

  if (!delivered) {
    await db.update(walletsTable).set({ balance: sql`balance + ${plan.price}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
    await db.insert(transactionsTable).values({
      userId: req.userId!, type: "cable", status: "failed", amount: plan.price.toString(),
      description: `${plan.name} for ${smartcardNumber} — delivery failed`, reference,
      metadata: { provider, planName: plan.name, smartcardNumber, providerError, rawResponse },
    });
    await db.insert(notificationsTable).values({
      userId: req.userId!, title: "Cable Subscription Failed",
      message: `Your ${plan.name} subscription failed. Your wallet has been refunded.`, type: "cable",
    });
    const userMsg = providerError
      ? `Cable subscription failed: ${providerError}. Your wallet has been refunded.`
      : "Cable subscription failed. Your wallet has been refunded.";
    res.status(422).json({ error: userMsg }); return;
  }

  const [tx] = await db.insert(transactionsTable).values({
    userId: req.userId!, type: "cable", status: "success", amount: plan.price.toString(),
    description: `${plan.name} for ${smartcardNumber}`, reference,
    metadata: { provider, planName: plan.name, smartcardNumber },
  }).returning();
  await db.insert(notificationsTable).values({
    userId: req.userId!, title: "Cable Subscription Successful",
    message: `${plan.name} activated for smartcard ${smartcardNumber}.`, type: "cable",
  });
  void creditResellerCommission(req.userId!, plan.price, `${plan.name} cable`, req.log);
  res.json({ id: tx.id, type: tx.type, status: tx.status, amount: parseFloat(tx.amount), description: tx.description, reference: tx.reference, metadata: tx.metadata, userId: tx.userId, createdAt: tx.createdAt });
});

// ── EXAM TOKENS ───────────────────────────────────────────────────────────────
router.get("/exam/types", async (_req, res): Promise<void> => {
  const types = await db.select().from(examTypesTable);
  res.json(types.map((t) => ({ id: t.id, name: t.name, code: t.code, price: parseFloat(t.price), description: t.description })));
});

router.post("/exam/purchase", authenticate, async (req: AuthRequest, res): Promise<void> => {
  const parsed = PurchaseExamTokenBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { examTypeId, quantity, phone } = parsed.data;

  const [examType] = await db.select().from(examTypesTable).where(eq(examTypesTable.id, examTypeId));
  if (!examType) { res.status(404).json({ error: "Exam type not found" }); return; }
  if (!isActiveProviderConfigured()) { res.status(503).json({ error: "Service temporarily unavailable. Please try again later." }); return; }

  // KYB Data numeric IDs for exam types (only used if the exam is routed to
  // KYB Data; BigISub/EasyAccess/Clubkonnect route by examCode instead, see
  // activePurchaseExam in lib/providers/activeProvider.ts).
  const KYB_EXAM_IDS: Record<string, number> = { NECO: 19, WAEC: 34 };
  const kybExamId = KYB_EXAM_IDS[examType.code.toUpperCase()] ?? 0;

  const totalCost = parseFloat(examType.price) * quantity;
  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  if (parseFloat(wallet.balance) < totalCost) {
    res.status(400).json({ error: "Insufficient wallet balance. Please fund your wallet to continue." }); return;
  }

  await db.update(walletsTable).set({ balance: sql`balance - ${totalCost}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
  const reference = `EXAM-${Date.now()}`;
  let pins: Array<{ pin: string; serial: string }> = [];
  let delivered = false;
  let providerError = "";
  let rawResponse: any = null;
  let isTimeout = false;

  try {
    const r = await activePurchaseExam({ examid: kybExamId, quantity, examCode: examType.code });
    rawResponse = r;
    req.log?.info({ r }, "KYB Data exam response");
    const success = (r as any).success === true;
    const st = String((r as any).status ?? "").toLowerCase();
    const msg = String(r.message ?? "").toLowerCase();
    delivered = success || st === "success" || st === "200" || st === "00"
      || msg.includes("success") || msg.includes("successful") || msg.includes("delivered");
    const pinsRaw = r.pins ?? (r as any).data?.pins ?? (r as any).data ?? [];
    if (delivered && Array.isArray(pinsRaw)) pins = pinsRaw.map((p: any) => ({ pin: String(p.pin ?? p.token ?? p), serial: String(p.serial ?? p.sn ?? "") }));
    if (!delivered) {
      providerError = (r as any).data?.error_message?.api_response
        || (r as any).error_message?.api_response
        || r.message || "";
    }
  } catch (err: any) {
    req.log?.error({ err }, "Exam purchase error");
    providerError = err?.message ?? "";
    isTimeout = err instanceof ProviderTimeoutError;
  }

  if (!delivered && isTimeout) {
    const tx = await recordPendingPurchase({
      userId: req.userId!, type: "exam", amount: totalCost, reference,
      description: `${quantity}x ${examType.name} token(s) — awaiting confirmation`,
      metadata: { examType: examType.code, quantity, phone, providerError },
    });
    res.status(202).json({ id: tx.id, status: "pending", message: "Your exam token purchase is being confirmed. We'll notify you shortly — please don't retry yet." });
    return;
  }

  if (!delivered) {
    await db.update(walletsTable).set({ balance: sql`balance + ${totalCost}`, updatedAt: new Date() }).where(eq(walletsTable.userId, req.userId!));
    await db.insert(transactionsTable).values({
      userId: req.userId!, type: "exam", status: "failed", amount: totalCost.toString(),
      description: `${quantity}x ${examType.name} token(s) — delivery failed`, reference,
      metadata: { examType: examType.code, quantity, phone, providerError, rawResponse },
    });
    await db.insert(notificationsTable).values({
      userId: req.userId!, title: "Exam Token Purchase Failed",
      message: `Your ${examType.name} token purchase failed. Your wallet has been refunded.`, type: "exam",
    });
    const userMsg = providerError
      ? `Exam token delivery failed: ${providerError}. Your wallet has been refunded.`
      : "Exam token delivery failed. Your wallet has been refunded. Please contact support.";
    res.status(422).json({ error: userMsg }); return;
  }

  const [tx] = await db.insert(transactionsTable).values({
    userId: req.userId!, type: "exam", status: "success", amount: totalCost.toString(),
    description: `${quantity}x ${examType.name} token(s)`, reference,
    metadata: { examType: examType.code, quantity, pins, phone },
  }).returning();
  await db.insert(notificationsTable).values({
    userId: req.userId!, title: "Exam Token Purchase Successful",
    message: `${quantity} ${examType.name} PIN(s) purchased successfully.`, type: "exam",
  });
  void creditResellerCommission(req.userId!, totalCost, `${examType.name} exam token`, req.log);
  res.json({ id: tx.id, status: "success", pins, examType: examType.code, amount: totalCost, createdAt: tx.createdAt });
});

export default router;
